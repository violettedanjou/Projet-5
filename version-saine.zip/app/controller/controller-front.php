<?php 

namespace app\controller_front;

class controller {
	function test() {
		var_dump("dans controller test");
	}
}


?>