let currentWeather = new Weather();
currentWeather.display();