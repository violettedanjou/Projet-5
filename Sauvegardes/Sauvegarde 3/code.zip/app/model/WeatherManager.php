<?php
namespace app\model;

require "vendor/autoload.php";
use app\model\Manager;

class WeatherManager extends Manager 
{
    
}